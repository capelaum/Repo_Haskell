-- soma dos elementos lista 
soma_lista [] = 0
soma_lista (x:xs) = x + soma_lista xs

-- dobro da soma dos elementos lista 
dobro_soma [] = 0
dobro_soma lista = 2 * (soma_lista lista)

{- 5. Escreva uma função que calcule o dobro da soma dos elementos de uma lista.

  * soma_lista: Função que calcula a soma dos elementos da lista
  * dobro_soma: Funcao que apenas retorna o dobro do retorno da soma dos elementos lista
-}